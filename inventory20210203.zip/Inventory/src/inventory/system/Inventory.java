package inventory.system;
public class Inventory {
    public static void main(String[] args) throws Exception{
   }  
}

