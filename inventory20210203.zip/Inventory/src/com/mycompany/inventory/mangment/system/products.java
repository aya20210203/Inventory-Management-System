package com.mycompany.inventory.mangment.system;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
public class products {
   private String productName;
    private int price;
    private int quantity;
    private String productionDate;
    private String expirationDate;
    private int rate;
    private String categoryName;
    public String getCategoryName() {
        return categoryName;
    }
   public static ResultSet show_products(int i) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
    public String getProductName() {
        return productName;
    }
    public void setProductName(String productName) {
        this.productName = productName;     
    }
    public int getPrice() {
        return price;
    }
    public void setPrice(int price) {
        this.price = price;
    }
    public int getQuantity() {
        return quantity;
    }
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    public String getProductionDate() {
        return productionDate;
    }
    public void setProductionDate(String productionDate) {
        this.productionDate = productionDate;
    }
    public String getExpirationDate() {
        return expirationDate;
    }
    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }
    public int getRate() {
        return rate;
    }
    public void setRate(int rate) {
        this.rate = rate;
    }
    public static void change_quantity(String product_name, int ordered_quantity){ 
            try { 
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
            Statement st = c.createStatement(); 
            String sql = "select * from product where [name] = '"+product_name+"'"; 
            ResultSet s = st.executeQuery(sql); 
            int x= 0; while(s.next()){ 
                x = s.getInt("quantity"); 
            } 
            if(ordered_quantity > x) 
                JOptionPane.showMessageDialog(null, "too much quantity", "Error", JOptionPane.ERROR_MESSAGE); 
            else{ 
                x = x - ordered_quantity; 
                sql="update product set quantity = '"+x+"' where [name] = '"+product_name+"'";  
                int y = st.executeUpdate(sql); 
                if(y==1)  
                    JOptionPane.showMessageDialog(null,"product ordered","SUCCESS",JOptionPane.INFORMATION_MESSAGE);  
                else  
                    JOptionPane.showMessageDialog(null,"order failed","Failed",JOptionPane.INFORMATION_MESSAGE);  
            } 
        } catch (ClassNotFoundException ex) { 
            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE); 
        } catch (SQLException ex) { 
            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
        } 
    }
    public static void add_product(String name,int price,int quantity,String category_name,String production_date,String expiration_date){   
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
            Statement st = c.createStatement();
            String sql="insert into product(name,price,quantity,category_name,production_date,expiration_date) values('"+name+"','"+price+"','"+quantity+"','"+category_name+"','"+production_date+"','"+expiration_date+"')";
            int x = st.executeUpdate(sql);
            if(x==1)
                JOptionPane.showMessageDialog(null,"data has been recorded","SUCCESS",JOptionPane.INFORMATION_MESSAGE);
            else
                JOptionPane.showMessageDialog(null,"data has NOT been recorded","Failed",JOptionPane.INFORMATION_MESSAGE);
            } catch (ClassNotFoundException ex) { 
                JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE); 
            } catch (SQLException ex) { 
                Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
        }
     } 
    public static void update_product(String name,int price,int quantity,String category_name,String production_date,String expiration_date){   
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
            Statement st = c.createStatement();
            String sql="update product set price = '"+price+"', quantity = '"+quantity+"', category_name = '"+category_name+"', production_date = '"+production_date+"', expiration_date = '"+expiration_date+"' where name ='"+name+"'";
            int x = st.executeUpdate(sql);
            if(x==1)
                JOptionPane.showMessageDialog(null,"data has been recorded","SUCCESS",JOptionPane.INFORMATION_MESSAGE);
            else
                JOptionPane.showMessageDialog(null,"data has NOT been recorded","Failed",JOptionPane.INFORMATION_MESSAGE);
            } catch (ClassNotFoundException ex) { 
                JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE); 
            } catch (SQLException ex) { 
                Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
        }
     }
    public int delete_product(String name){
        int x=0;
         try { 
           Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
           Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");  
           Statement st = c.createStatement(); 
            String sql = "delete from product where name ='"+name+"'" ; 
            x = st.executeUpdate(sql); 
        } catch (ClassNotFoundException ex) { 
            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE); 
        } catch (SQLException ex) { 
            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
        }
        return x;        
    }
    public static ResultSet search_product(String name){
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
            Statement st = c.createStatement();
            String sql = "select * from product where name = '"+name+"'";
            ResultSet resultSet = st.executeQuery(sql);
            return resultSet;
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
        }
    return null;
    }  
    public static ResultSet show_products(){
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
            Statement st = c.createStatement();
            String sql = "select id, name, price, category_name, production_date, expiration_date, quantity from product order by id asc";
            ResultSet resultSet = st.executeQuery(sql);
            return resultSet;
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    public static ResultSet search_pcat(String name){ 
        try { 
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
            Statement st = c.createStatement(); 
            String sql = "select * from product where category_name = '"+name+"'"; 
            ResultSet resultSet = st.executeQuery(sql); 
            return resultSet; 
        } catch (ClassNotFoundException ex) { 
            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE); 
        } catch (SQLException ex) { 
            Logger.getLogger(inventory.system.Inventory.class.getName()).log(Level.SEVERE, null, ex); 
        } 
        return null; 
    }    
    public static int is_product(String name){ 
        try { 
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
            Statement st = c.createStatement(); int count = 0;  
            String sql = "select * from product where name = '"+name+"'"; 
            ResultSet s = st.executeQuery(sql);  
            while (s.next()) {count++;} 
            return count; 
        } catch (ClassNotFoundException ex) { 
            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE); 
        } catch (SQLException ex) { 
            Logger.getLogger(inventory.system.Inventory.class.getName()).log(Level.SEVERE, null, ex); 
        } 
        return 0; 
    } 
        public static int is_category(String name){ 
        try { 
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
            Statement st = c.createStatement(); int count = 0;  
            String sql = "select * from category where name = '"+name+"'"; 
            ResultSet s = st.executeQuery(sql);  
            while (s.next()) {count++;} 
            return count; 
        } catch (ClassNotFoundException ex) { 
            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE); 
        } catch (SQLException ex) { 
            Logger.getLogger(inventory.system.Inventory.class.getName()).log(Level.SEVERE, null, ex); 
        } 
        return 0; 
    } 
    public static ResultSet searchp(String name){ 
        ResultSet s = null; 
        if(is_product(name) == 1) 
            s = search_product(name); 
        else if(is_category(name) == 1) 
            s = search_pcat(name); 
        return s; 
    }
    public static ResultSet show_rates(){
    try {
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
        Statement st = c.createStatement();
        String sql = "select [name], rate from product order by [name]";
        ResultSet resultSet = st.executeQuery(sql);
        return resultSet;
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
