package com.mycompany.inventory.mangment.system;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
public class supplier{
    private String supplierName;
    private String productName;
    public String getProductName() {
        return productName;
    }
    public void setProductName(String productName) {
        this.productName = productName;
    }
    public String getSupplierName() {
        return supplierName;
    }
    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }
    public static void add_supplier(String name,String product_name){   
    try {
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
        Statement st = c.createStatement();
        String sql="insert into supplier([name],product_name) values('"+name+"','"+product_name+"')";
        int x = st.executeUpdate(sql);
        if(x==1)
            JOptionPane.showMessageDialog(null,"data has been recorded","SUCCESS",JOptionPane.INFORMATION_MESSAGE);
        else
            JOptionPane.showMessageDialog(null,"data has NOT been recorded","Failed",JOptionPane.INFORMATION_MESSAGE);
        } catch (ClassNotFoundException ex) { 
        JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE); 
        } catch (SQLException ex) { 
        Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
        }
     } 
  public static void update_supplier(String name,String product_name)
    {
    try {
       Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
       Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
       Statement st = c.createStatement();
       String sql="update supplier set product_name = '"+product_name+"' where name = '"+name+"'";
       int x = st.executeUpdate(sql);
       if(x==1)
           JOptionPane.showMessageDialog(null,"data has been recorded","SUCCESS",JOptionPane.INFORMATION_MESSAGE);
       else
           JOptionPane.showMessageDialog(null,"data has NOT been recorded","Failed",JOptionPane.INFORMATION_MESSAGE);
       } catch (ClassNotFoundException ex) { 
       JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE); 
       } catch (SQLException ex) { 
       Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
       }
    }
    public static int delete_supplier(String name){  
        int x=0;  
        try { 
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");  
            Statement st = c.createStatement(); 
            String sql = "delete from supplier where name ='"+name+"'" ; 
            x = st.executeUpdate(sql);
        } catch (ClassNotFoundException ex) { 
            JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE); 
        } catch (SQLException ex) { 
            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
        }
        return x;
    }
   public static ResultSet show_supplier(){
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
            Statement st = c.createStatement();
            String sql = "select * from supplier order by id";
            ResultSet resultSet = st.executeQuery(sql);
            return resultSet;
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
        }
    return null;
    }
}
