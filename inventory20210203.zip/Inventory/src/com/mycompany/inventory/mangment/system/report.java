
package com.mycompany.inventory.mangment.system;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
public class report {
  private String productName;
  private int rate;
    public String getProductName() {
        return productName;
    }
    public void setProductName(String productName) {
        this.productName = productName;
    }
    public int getRate() {
        return rate;
    }
    public void setRate(int rate) {
        this.rate = rate;
    }
    public static int add_rate(String name, int rate){    
        try { 
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
            Statement st = c.createStatement(); 
            String sql="update product set rate = '"+rate+"' where [name] = '"+name+"'"; 
            int x = st.executeUpdate(sql); 
                return x;
            } catch (ClassNotFoundException ex) {  
                JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE);  
            } catch (SQLException ex) {  
                Logger.getLogger(inventory.system.Inventory.class.getName()).log(Level.SEVERE, null, ex);  
        } 
      return  0;
     } 
     public static ResultSet show_rates(){
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
            Statement st = c.createStatement();
            String sql = "select name, rate from product order by [name]";
            ResultSet resultSet = st.executeQuery(sql);
            return resultSet;
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            Logger.getLogger(inventory.system.Inventory.class.getName()).log(Level.SEVERE, null, ex);
        }
    return null;
    }
}
