package com.mycompany.inventory.mangment.system;
public class Inventory {
    public static void main(String[] args) {
    }
    
}
