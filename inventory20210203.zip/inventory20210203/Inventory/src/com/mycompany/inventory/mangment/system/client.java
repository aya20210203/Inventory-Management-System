/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inventory.mangment.system;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 *
 * @author asus
 */
public class client {
    private String email;
    private String password;
    private String answer;
    private String question;

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

   

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
  public static void add_client( String email,String pass){ 
      try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
            Statement st = c.createStatement();
        String sql="insert into client(email,password) values('"+email+"','"+pass+"')";
        int x = st.executeUpdate(sql);
        if(x==1)
            JOptionPane.showMessageDialog(null,"data has been recorded","SUCCESS",JOptionPane.INFORMATION_MESSAGE);
        else
            JOptionPane.showMessageDialog(null,"data has NOT been recorded","Failed",JOptionPane.INFORMATION_MESSAGE);
        } catch (ClassNotFoundException ex) { 
            JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE); 
        } catch (SQLException ex) { 
            Logger.getLogger(inventory.system.Inventory.class.getName()).log(Level.SEVERE, null, ex); 
        }
    }
    public static int is_client(String email, String password){
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
            Statement st = c.createStatement(); int count = 0; 
            String sql = "select * from client where email = '"+email+"' and password = '"+password+"'";
            ResultSet s = st.executeQuery(sql); 
            while (s.next()) {count++;}
            return count;
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
        }
    return 0;
    }
    public static String securityQ(String email){ 
            try { 
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
            Statement st = c.createStatement(); 
            String sql = "select * from client where email = '"+email+"'"; 
            ResultSet s = st.executeQuery(sql); 
            String q = null; while(s.next()){ 
                q = s.getString("securityQ"); 
            } 
            return q; 
        } catch (ClassNotFoundException ex) { 
            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE); 
        } catch (SQLException ex) { 
            Logger.getLogger(inventory.system.Inventory.class.getName()).log(Level.SEVERE, null, ex); 
        } 
            return null; 
    } 
    public static void change_password(String email, String answer, String new_password){ 
            try { 
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
            Statement st = c.createStatement(); 
            String sql = "select * from client where email = '"+email+"'"; 
            ResultSet s = st.executeQuery(sql); 
            String a = null; while(s.next()){ 
                a = s.getString("securityA"); 
            } 
            if(a.equals(answer)) 
            { 
                sql = "update client set password = '"+new_password+"' where email= '"+email+"'"; 
                int i = st.executeUpdate(sql);
                JOptionPane.showMessageDialog(null,"password changed","SUCCESS",JOptionPane.INFORMATION_MESSAGE);  
            } 
            else 
                JOptionPane.showMessageDialog(null,"wrong answer to security question!","Failed",JOptionPane.INFORMATION_MESSAGE);  
        } catch (ClassNotFoundException ex) { 
            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE); 
        } catch (SQLException ex) { 
            Logger.getLogger(inventory.system.Inventory.class.getName()).log(Level.SEVERE, null, ex); 
        } 
    }
    
        public static void delete_client(String email){    
        try {  
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");   
            Statement st = c.createStatement();  
            String sql = "delete from client where email = '"+email+"'" ;  
            int x = st.executeUpdate(sql); 
            if(x==1) 
                JOptionPane.showMessageDialog(null,"account is deleted","SUCCESS",JOptionPane.INFORMATION_MESSAGE); 
            else 
                JOptionPane.showMessageDialog(null,"account is not deleted","Failed",JOptionPane.INFORMATION_MESSAGE);  
        } catch (ClassNotFoundException ex) {  
            JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE);  
        } catch (SQLException ex) {  
            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);  
        } 
    }
}
