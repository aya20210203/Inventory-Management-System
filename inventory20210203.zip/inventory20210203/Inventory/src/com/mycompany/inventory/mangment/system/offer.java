/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inventory.mangment.system;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 *
 * @author asus
 */
public class offer{
     private String productName;

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }
     private int quantity;
     private String startDate;
     private String endDate;
     private int percentage;

    

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public int getPercentage() {
        return percentage;
    }

    public void setPercentage(int percentage) {
        this.percentage = percentage;
    }
      public static void add_offer(String product_name,int quantity,String start_date,String end_date,int percentage){   
      try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
            Statement st = c.createStatement();
            String sql="insert into offer(product_name,quantity,start_date,end_date,percentage) values('"+product_name+"','"+quantity+"','"+start_date+"','"+end_date+"','"+percentage+"')";
            int x = st.executeUpdate(sql);
            if(x==1)
                JOptionPane.showMessageDialog(null,"data has been recorded","SUCCESS",JOptionPane.INFORMATION_MESSAGE);
            else
                JOptionPane.showMessageDialog(null,"data has NOT been recorded","Failed",JOptionPane.INFORMATION_MESSAGE);
            } catch (ClassNotFoundException ex) { 
            JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE); 
            } catch (SQLException ex) { 
                Logger.getLogger(inventory.system.Inventory.class.getName()).log(Level.SEVERE, null, ex); 
            }
    }
      public static void update_offer(String name,int quantity,String start_date,String end_date, int percentage){    
      try { 
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
            Statement st = c.createStatement(); 
            String sql="update offer set quantity = '"+quantity+"', start_date = '"+start_date+"', end_date = '"+end_date+"', percentage = '"+percentage+"' where product_name ='"+name+"'"; 
            int x = st.executeUpdate(sql); 
            if(x==1) 
                JOptionPane.showMessageDialog(null,"data has been recorded","SUCCESS",JOptionPane.INFORMATION_MESSAGE); 
            else 
                JOptionPane.showMessageDialog(null,"data has NOT been recorded","Failed",JOptionPane.INFORMATION_MESSAGE); 
            } catch (ClassNotFoundException ex) {  
                JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE);  
            } catch (SQLException ex) {  
                Logger.getLogger(inventory.system.Inventory.class.getName()).log(Level.SEVERE, null, ex);  
        } 
     }
     
     public static int delete_offer(String name){   
        int x=0;   
        try {  
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");   
            Statement st = c.createStatement();  
            String sql = "delete from offer where product_name = '"+name+"'" ;  
            x = st.executeUpdate(sql); 
        } catch (ClassNotFoundException ex) {  
            JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE);  
        } catch (SQLException ex) {  
            Logger.getLogger(inventory.system.Inventory.class.getName()).log(Level.SEVERE, null, ex);  
        } 
        return x; 
    }
         public static ResultSet show_offers(){
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
            Statement st = c.createStatement();
            String sql = "select * from offer order by product_name";
            ResultSet resultSet = st.executeQuery(sql);
            return resultSet;
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            Logger.getLogger(inventory.system.Inventory.class.getName()).log(Level.SEVERE, null, ex);
        }
    return null;
    }
}
