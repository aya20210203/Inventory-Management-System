/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inventory.mangment.system;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 *
 * @author asus
 */
public class invoice {
  

    public static ResultSet show_invoice(String email){ 
            try { 
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
            Statement st = c.createStatement(); 
            String sql = "select product_name, ordered_quantity, price from invoice inner join product on invoice.product_name = product.[name] where client_email = '"+email+"' order by product_name"; 
            ResultSet resultSet = st.executeQuery(sql); 
            return resultSet; 
        } catch (ClassNotFoundException ex) { 
            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE); 
        } catch (SQLException ex) { 
            Logger.getLogger(inventory.system.Inventory.class.getName()).log(Level.SEVERE, null, ex); 
        } 
    return null; 
    } 
     public static void change_quantity(String product_name, int ordered_quantity){ 
            try { 
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
            Statement st = c.createStatement(); 
            String sql = "select * from product where [name] = '"+product_name+"'"; 
            ResultSet s = st.executeQuery(sql); 
            int x= 0; while(s.next()){ 
                x = s.getInt("quantity"); 
            } 
            if(ordered_quantity > x) 
                JOptionPane.showMessageDialog(null, "too much quantity", "Error", JOptionPane.ERROR_MESSAGE); 
            else{ 
                x = x - ordered_quantity; 
                sql="update product set quantity = '"+x+"' where [name] = '"+product_name+"'";  
                int y = st.executeUpdate(sql); 
                if(y==1)  
                    JOptionPane.showMessageDialog(null,"product ordered","SUCCESS",JOptionPane.INFORMATION_MESSAGE);  
                else  
                    JOptionPane.showMessageDialog(null,"order failed","Failed",JOptionPane.INFORMATION_MESSAGE);  
            } 
        } catch (ClassNotFoundException ex) { 
            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE); 
        } catch (SQLException ex) { 
            Logger.getLogger(inventory.system.Inventory.class.getName()).log(Level.SEVERE, null, ex); 
        } 
    }
         public static int price(String name){  
            try {  
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");  
            Statement st = c.createStatement();  
            String sql = "select * from product where [name] = '"+name+"'";  
            ResultSet s = st.executeQuery(sql);  
            int x = 0; while(s.next()){  
                x = s.getInt("price");  
            }  
            return x; 
            } catch (ClassNotFoundException ex) {  
            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE);  
        } catch (SQLException ex) {  
            Logger.getLogger(inventory.system.Inventory.class.getName()).log(Level.SEVERE, null, ex);  
        }  
            return 0; 
    }
                 public static void add_invoice(String email, String product_name, int ordered_quantity){  
            try {  
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");  
            Statement st = c.createStatement();  
            String sql = "select * from product where [name] = '"+product_name+"'";  
            ResultSet s = st.executeQuery(sql);  
            int x= 0; while(s.next()){  
                x = s.getInt("quantity");  
            }  
            if(ordered_quantity > x)  
                JOptionPane.showMessageDialog(null, "too much quantity", "Error", JOptionPane.ERROR_MESSAGE);  
            else{  
                x = x - ordered_quantity;  
                sql="update product set quantity = '"+x+"' where [name] = '"+product_name+"'";   
                int y = st.executeUpdate(sql); 
                sql="insert into invoice values('"+email+"','"+product_name+"','"+ordered_quantity+"')"; 
                int z = st.executeUpdate(sql); 
                if(y==1 && z==1)   
                    JOptionPane.showMessageDialog(null,"product ordered","SUCCESS",JOptionPane.INFORMATION_MESSAGE);   
                else   
                    JOptionPane.showMessageDialog(null,"order failed","Failed",JOptionPane.INFORMATION_MESSAGE);   
            }  
        } catch (ClassNotFoundException ex) {  
            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE);  
        } catch (SQLException ex) {  
            Logger.getLogger(inventory.system.Inventory.class.getName()).log(Level.SEVERE, null, ex);  
        }  
    } 
          public static ResultSet show_products_client(){ 
            try { 
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
            Statement st = c.createStatement(); 
            String sql = "select name, quantity, price from product order by [name]"; 
            ResultSet resultSet = st.executeQuery(sql); 
            return resultSet; 
        } catch (ClassNotFoundException ex) { 
            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE); 
        } catch (SQLException ex) { 
            Logger.getLogger(inventory.system.Inventory.class.getName()).log(Level.SEVERE, null, ex); 
        } 
    return null; 
    }
        
}
