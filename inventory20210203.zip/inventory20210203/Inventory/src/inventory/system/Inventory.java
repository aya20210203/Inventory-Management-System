package inventory.system;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
public class Inventory {
    public static void main(String[] args) throws Exception{
 
   }  
//    public static void change_quantity(String product_name, int ordered_quantity){ 
//            try { 
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
//            Statement st = c.createStatement(); 
//            String sql = "select * from product where [name] = '"+product_name+"'"; 
//            ResultSet s = st.executeQuery(sql); 
//            int x= 0; while(s.next()){ 
//                x = s.getInt("quantity"); 
//            } 
//            if(ordered_quantity > x) 
//                JOptionPane.showMessageDialog(null, "too much quantity", "Error", JOptionPane.ERROR_MESSAGE); 
//            else{ 
//                x = x - ordered_quantity; 
//                sql="update product set quantity = '"+x+"' where [name] = '"+product_name+"'";  
//                int y = st.executeUpdate(sql); 
//                if(y==1)  
//                    JOptionPane.showMessageDialog(null,"product ordered","SUCCESS",JOptionPane.INFORMATION_MESSAGE);  
//                else  
//                    JOptionPane.showMessageDialog(null,"order failed","Failed",JOptionPane.INFORMATION_MESSAGE);  
//            } 
//        } catch (ClassNotFoundException ex) { 
//            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE); 
//        } catch (SQLException ex) { 
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
//        } 
//    }
//    public static int is_client(String email, String password){
//        try {
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
//            Statement st = c.createStatement(); int count = 0; 
//            String sql = "select * from client where email = '"+email+"' and password = '"+password+"'";
//            ResultSet s = st.executeQuery(sql); 
//            while (s.next()) {count++;}
//            return count;
//        } catch (ClassNotFoundException ex) {
//            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE);
//        } catch (SQLException ex) {
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    return 0;
//    }
//    public static int is_admin(String name, String password){
//        try {
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
//            Statement st = c.createStatement(); int count = 0; 
//            String sql = "select * from admin where name = '"+name+"' and password = '"+password+"'";
//            ResultSet s = st.executeQuery(sql); 
//            while (s.next()) {count++;}
//            return count;
//        } catch (ClassNotFoundException ex) {
//            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE);
//        } catch (SQLException ex) {
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    return 0;
//    }
//    public static ResultSet show_products(){
//    try {
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
//            Statement st = c.createStatement();
//            String sql = "select id, name, price, category_name, production_date, expiration_date, quantity from product order by id asc";
//            ResultSet resultSet = st.executeQuery(sql);
//            return resultSet;
//        } catch (ClassNotFoundException ex) {
//            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE);
//        } catch (SQLException ex) {
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    return null;
//    }
//    public static ResultSet show_offers(){
//        try {
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
//            Statement st = c.createStatement();
//            String sql = "select * from offer";
//            ResultSet resultSet = st.executeQuery(sql);
//            return resultSet;
//        } catch (ClassNotFoundException ex) {
//            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE);
//        } catch (SQLException ex) {
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    return null;
//    }
//    public static ResultSet show_rates(){
//            try {
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
//            Statement st = c.createStatement();
//            String sql = "select name, rate from product";
//            ResultSet resultSet = st.executeQuery(sql);
//            return resultSet;
//        } catch (ClassNotFoundException ex) {
//            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE);
//        } catch (SQLException ex) {
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    return null;
//    }
//    public static ResultSet show_category(){
//            try {
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
//            Statement st = c.createStatement();
//            String sql = "select * from category";
//            ResultSet resultSet = st.executeQuery(sql);
//            return resultSet;
//        } catch (ClassNotFoundException ex) {
//            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE);
//        } catch (SQLException ex) {
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    return null;
//    }
//    public static ResultSet show_expired(){
//            try {
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
//            Statement st = c.createStatement();
//            String sql = "select id, name, category_name, quantity, expiration_date from product";
//            ResultSet resultSet = st.executeQuery(sql);
//            return resultSet;
//        } catch (ClassNotFoundException ex) {
//            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE);
//        } catch (SQLException ex) {
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    return null;
//    }
//    public static ResultSet show_invoice(int id){
//            try {
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
//            Statement st = c.createStatement();
//            String sql = "select product_name, quantity, price from product inner join invoice on "
//                    + "invoice.product_name = product.name where client_id = '"+id+"'";
//            ResultSet resultSet = st.executeQuery(sql);
//            return resultSet;
//        } catch (ClassNotFoundException ex) {
//            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE);
//        } catch (SQLException ex) {
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    return null;
//    }
//    public static ResultSet show_supplier(){
//        try {
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
//            Statement st = c.createStatement();
//            String sql = "select * from supplier";
//            ResultSet resultSet = st.executeQuery(sql);
//            return resultSet;
//        } catch (ClassNotFoundException ex) {
//            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE);
//        } catch (SQLException ex) {
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    return null;
//    }
//    public static ResultSet search_product(String name){
//        try {
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
//            Statement st = c.createStatement();
//            String sql = "select * from product where name = '"+name+"'";
//            ResultSet resultSet = st.executeQuery(sql);
//            return resultSet;
//        } catch (ClassNotFoundException ex) {
//            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE);
//        } catch (SQLException ex) {
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    return null;
//    }    
//    public static int delete_product(String name){
//        int x=0;
//         try { 
//           Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
//           Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");  
//           Statement st = c.createStatement(); 
//            String sql = "delete from product where name ='"+name+"'" ; 
//            x = st.executeUpdate(sql); 
//        } catch (ClassNotFoundException ex) { 
//            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE); 
//        } catch (SQLException ex) { 
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
//        }
//        return x;        
//    }
//    public static int delete_supplier(String name){  
//        int x=0;  
//        try { 
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");  
//            Statement st = c.createStatement(); 
//            String sql = "delete from supplier where name ='"+name+"'" ; 
//            x = st.executeUpdate(sql);
//        } catch (ClassNotFoundException ex) { 
//            JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE); 
//        } catch (SQLException ex) { 
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
//        }
//        return x;
//    }
//    public static void add_client( String email,String pass){ 
//      try {
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
//            Statement st = c.createStatement();
//        String sql="insert into client(email,password) values('"+email+"','"+pass+"')";
//        int x = st.executeUpdate(sql);
//        if(x==1)
//            JOptionPane.showMessageDialog(null,"data has been recorded","SUCCESS",JOptionPane.INFORMATION_MESSAGE);
//        else
//            JOptionPane.showMessageDialog(null,"data has NOT been recorded","Failed",JOptionPane.INFORMATION_MESSAGE);
//        } catch (ClassNotFoundException ex) { 
//            JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE); 
//        } catch (SQLException ex) { 
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
//        }
//    }
//    public static void add_category(String name){   
//      try {
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
//            Statement st = c.createStatement();
//            String sql="insert into category(name) values('"+name+"')";
//            int x = st.executeUpdate(sql);
//            if(x==1)
//                JOptionPane.showMessageDialog(null,"data has been recorded","SUCCESS",JOptionPane.INFORMATION_MESSAGE);
//            else
//                JOptionPane.showMessageDialog(null,"data has NOT been recorded","Failed",JOptionPane.INFORMATION_MESSAGE);
//            } catch (ClassNotFoundException ex) { 
//                JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE); 
//            } catch (SQLException ex) { 
//                Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
//        }
//     }
//    public static void add_offer(String product_name,int quantity,String start_date,String end_date,int percentage){   
//      try {
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
//            Statement st = c.createStatement();
//            String sql="insert into offer(product_name,quantity,start_date,end_date,percentage) values('"+product_name+"','"+quantity+"','"+start_date+"','"+end_date+"','"+percentage+"')";
//            int x = st.executeUpdate(sql);
//            if(x==1)
//                JOptionPane.showMessageDialog(null,"data has been recorded","SUCCESS",JOptionPane.INFORMATION_MESSAGE);
//            else
//                JOptionPane.showMessageDialog(null,"data has NOT been recorded","Failed",JOptionPane.INFORMATION_MESSAGE);
//            } catch (ClassNotFoundException ex) { 
//            JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE); 
//            } catch (SQLException ex) { 
//                Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
//            }
//    }
//    public static void add_product(String name,int price,int quantity,String category_name,String production_date,String expiration_date){   
//      try {
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
//            Statement st = c.createStatement();
//            String sql="insert into product(name,price,quantity,category_name,production_date,expiration_date) values('"+name+"','"+price+"','"+quantity+"','"+category_name+"','"+production_date+"','"+expiration_date+"')";
//            int x = st.executeUpdate(sql);
//            if(x==1)
//                JOptionPane.showMessageDialog(null,"data has been recorded","SUCCESS",JOptionPane.INFORMATION_MESSAGE);
//            else
//                JOptionPane.showMessageDialog(null,"data has NOT been recorded","Failed",JOptionPane.INFORMATION_MESSAGE);
//            } catch (ClassNotFoundException ex) { 
//                JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE); 
//            } catch (SQLException ex) { 
//                Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
//        }
//     } 
//    public static void add_supplier(String name,String product_name){   
//      try {
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
//            Statement st = c.createStatement();
//            String sql="insert into supplier([name],product_name) values('"+name+"','"+product_name+"')";
//            int x = st.executeUpdate(sql);
//            if(x==1)
//                JOptionPane.showMessageDialog(null,"data has been recorded","SUCCESS",JOptionPane.INFORMATION_MESSAGE);
//            else
//                JOptionPane.showMessageDialog(null,"data has NOT been recorded","Failed",JOptionPane.INFORMATION_MESSAGE);
//            } catch (ClassNotFoundException ex) { 
//            JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE); 
//            } catch (SQLException ex) { 
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
//            }
//     } 
//    public static void update_product(String name,int price,int quantity,String category_name,String production_date,String expiration_date){   
//      try {
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
//            Statement st = c.createStatement();
//            String sql="update product set price = '"+price+"', quantity = '"+quantity+"', category_name = '"+category_name+"', production_date = '"+production_date+"', expiration_date = '"+expiration_date+"' where name ='"+name+"'";
//            int x = st.executeUpdate(sql);
//            if(x==1)
//                JOptionPane.showMessageDialog(null,"data has been recorded","SUCCESS",JOptionPane.INFORMATION_MESSAGE);
//            else
//                JOptionPane.showMessageDialog(null,"data has NOT been recorded","Failed",JOptionPane.INFORMATION_MESSAGE);
//            } catch (ClassNotFoundException ex) { 
//                JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE); 
//            } catch (SQLException ex) { 
//                Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
//        }
//     }
//    public static void update_supplier(String name,String product_name)
//    {
//         try {
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
//            Statement st = c.createStatement();
//            String sql="update supplier set product_name = '"+product_name+"' where name = '"+name+"'";
//            int x = st.executeUpdate(sql);
//            if(x==1)
//                JOptionPane.showMessageDialog(null,"data has been recorded","SUCCESS",JOptionPane.INFORMATION_MESSAGE);
//            else
//                JOptionPane.showMessageDialog(null,"data has NOT been recorded","Failed",JOptionPane.INFORMATION_MESSAGE);
//            } catch (ClassNotFoundException ex) { 
//            JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE); 
//            } catch (SQLException ex) { 
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
//            }
//    }

//    public static void add_rate(String name, int rate){    
//      try { 
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
//            Statement st = c.createStatement(); 
//            String sql="update product set rate = '"+rate+"' where [name] = '"+name+"'"; 
//            int x = st.executeUpdate(sql); 
//            if(x==1) 
//                JOptionPane.showMessageDialog(null,"Thanks!","SUCCESS",JOptionPane.INFORMATION_MESSAGE); 
//            else 
//                JOptionPane.showMessageDialog(null,"data has NOT been recorded","Failed",JOptionPane.INFORMATION_MESSAGE); 
//            } catch (ClassNotFoundException ex) {  
//                JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE);  
//            } catch (SQLException ex) {  
//                Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);  
//        } 
//     } 
//    public static void update_offer(String name,int quantity,String start_date,String end_date, int percentage){    
//      try { 
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
//            Statement st = c.createStatement(); 
//            String sql="update offer set quantity = '"+quantity+"', start_date = '"+start_date+"', end_date = '"+end_date+"' where product_name ='"+name+"'"; 
//            int x = st.executeUpdate(sql); 
//            if(x==1) 
//                JOptionPane.showMessageDialog(null,"data has been recorded","SUCCESS",JOptionPane.INFORMATION_MESSAGE); 
//            else 
//                JOptionPane.showMessageDialog(null,"data has NOT been recorded","Failed",JOptionPane.INFORMATION_MESSAGE); 
//            } catch (ClassNotFoundException ex) {  
//                JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE);  
//            } catch (SQLException ex) {  
//                Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);  
//        } 
//     } 
//    public static int delete_offer(String name){   
//        int x=0;   
//        try {  
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");   
//            Statement st = c.createStatement();  
//            String sql = "delete from offer where product_name = '"+name+"'" ;  
//            x = st.executeUpdate(sql); 
//        } catch (ClassNotFoundException ex) {  
//            JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE);  
//        } catch (SQLException ex) {  
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);  
//        } 
//        return x; 
//    }
//    public static int delete_category(String name){   
//        int x=0;   
//        try {  
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");   
//            Statement st = c.createStatement();  
//            String sql = "delete from category where name = '"+name+"'" ;  
//            x = st.executeUpdate(sql); 
//        } catch (ClassNotFoundException ex) {  
//            JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE);  
//        } catch (SQLException ex) {  
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);  
//        } 
//        return x; 
//    }
    
//    public static ResultSet search_pcat(String name){ 
//        try { 
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
//            Statement st = c.createStatement(); 
//            String sql = "select * from product where category_name = '"+name+"'"; 
//            ResultSet resultSet = st.executeQuery(sql); 
//            return resultSet; 
//        } catch (ClassNotFoundException ex) { 
//            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE); 
//        } catch (SQLException ex) { 
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
//        } 
//    return null; 
//    }    
//    public static int is_product(String name){ 
//        try { 
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
//            Statement st = c.createStatement(); int count = 0;  
//            String sql = "select * from product where name = '"+name+"'"; 
//            ResultSet s = st.executeQuery(sql);  
//            while (s.next()) {count++;} 
//            return count; 
//        } catch (ClassNotFoundException ex) { 
//            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE); 
//        } catch (SQLException ex) { 
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
//        } 
//    return 0; 
//    } 
//        public static int is_category(String name){ 
//        try { 
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
//            Statement st = c.createStatement(); int count = 0;  
//            String sql = "select * from category where name = '"+name+"'"; 
//            ResultSet s = st.executeQuery(sql);  
//            while (s.next()) {count++;} 
//            return count; 
//        } catch (ClassNotFoundException ex) { 
//            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE); 
//        } catch (SQLException ex) { 
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
//        } 
//    return 0; 
//    } 
//            public static ResultSet searchp(String name){ 
//                ResultSet s = null; 
//                if(is_product(name) == 1) 
//                    s = search_product(name); 
//                else if(is_category(name) == 1) 
//                    s = search_pcat(name); 
//                return s; 
//            }
//        public static ResultSet show_expiredp(){ 
//            try { 
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
//            Statement st = c.createStatement(); 
//            String sql = "select id, name, category_name, expiration_date from product"; 
//            ResultSet resultSet = st.executeQuery(sql); 
//            return resultSet; 
//        } catch (ClassNotFoundException ex) { 
//            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE); 
//        } catch (SQLException ex) { 
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
//        } 
//    return null; 
//    } 
//        public static ResultSet show_exquantity(){ 
//            try { 
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
//            Statement st = c.createStatement(); 
//            String sql = "select id, name, category_name, quantity from product where quantity < 50"; 
//            ResultSet resultSet = st.executeQuery(sql); 
//            return resultSet; 
//        } catch (ClassNotFoundException ex) { 
//            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE); 
//        } catch (SQLException ex) { 
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
//        } 
//    return null; 
//    }
//        public static void update_category(String old_name, String new_name){    
//            try { 
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
//            Statement st = c.createStatement(); 
//            String sql="update category set name = '"+new_name+"' where name = '"+old_name+"'"; 
//            int x = st.executeUpdate(sql); 
//            if(x==1) 
//                JOptionPane.showMessageDialog(null,"data has been recorded","SUCCESS",JOptionPane.INFORMATION_MESSAGE); 
//            else 
//                JOptionPane.showMessageDialog(null,"data has NOT been recorded","Failed",JOptionPane.INFORMATION_MESSAGE); 
//            } catch (ClassNotFoundException ex) {  
//                JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE);  
//            } catch (SQLException ex) {  
//                Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);  
//        } 
//     } 
//        public static int edit_client(String email, String password){try { 
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
//            Statement st = c.createStatement(); 
//            String sql = "update client set password = '"+password+"' where email = '"+email+"'"; 
//            int x = st.executeUpdate(sql);  
//            return x; 
//        } catch (ClassNotFoundException ex) { 
//            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE); 
//        } catch (SQLException ex) { 
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
//        } 
//    return 0; 
//    }

//public static void change_quantity(String product_name, int ordered_quantity){ 
//            try { 
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
//            Statement st = c.createStatement(); 
//            String sql = "select * from product where [name] = '"+product_name+"'"; 
//            ResultSet s = st.executeQuery(sql); 
//            int x= 0; while(s.next()){ 
//                x = s.getInt("quantity"); 
//            } 
//            if(ordered_quantity > x) 
//                JOptionPane.showMessageDialog(null, "too much quantity", "Error", JOptionPane.ERROR_MESSAGE); 
//            else{ 
//                x = x - ordered_quantity; 
//                sql="update product set quantity = '"+x+"' where [name] = '"+product_name+"'";  
//                int y = st.executeUpdate(sql); 
//                if(y==1)  
//                    JOptionPane.showMessageDialog(null,"product ordered","SUCCESS",JOptionPane.INFORMATION_MESSAGE);  
//                else  
//                    JOptionPane.showMessageDialog(null,"order failed","Failed",JOptionPane.INFORMATION_MESSAGE);  
//            } 
//        } catch (ClassNotFoundException ex) { 
//            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE); 
//        } catch (SQLException ex) { 
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
//        } 
//    }
//public static String securityQ(String email){ 
//            try { 
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
//            Statement st = c.createStatement(); 
//            String sql = "select * from client where email = '"+email+"'"; 
//            ResultSet s = st.executeQuery(sql); 
//            String q = null; while(s.next()){ 
//                q = s.getString("securityQ"); 
//            } 
//            return q; 
//        } catch (ClassNotFoundException ex) { 
//            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE); 
//        } catch (SQLException ex) { 
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
//        } 
//            return null; 
//    } 
//    public static void change_password(String email, String answer, String new_password){ 
//            try { 
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
//            Statement st = c.createStatement(); 
//            String sql = "select * from client where email = '"+email+"'"; 
//            ResultSet s = st.executeQuery(sql); 
//            String a = null; while(s.next()){ 
//                a = s.getString("securityA"); 
//            } 
//            if(a.equals(answer)) 
//            { 
//                sql = "update client set password = '"+new_password+"' where securityA = '"+answer+"'"; 
//                JOptionPane.showMessageDialog(null,"password changed","SUCCESS",JOptionPane.INFORMATION_MESSAGE);  
//            } 
//            else 
//                JOptionPane.showMessageDialog(null,"wrong answer to security question!","Failed",JOptionPane.INFORMATION_MESSAGE);  
//        } catch (ClassNotFoundException ex) { 
//            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE); 
//        } catch (SQLException ex) { 
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
//        } 
//    }
    
//    public static int price(String name){  
//            try {  
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");  
//            Statement st = c.createStatement();  
//            String sql = "select * from product where [name] = '"+name+"'";  
//            ResultSet s = st.executeQuery(sql);  
//            int x = 0; while(s.next()){  
//                x = s.getInt("price");  
//            }  
//            return x; 
//            } catch (ClassNotFoundException ex) {  
//            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE);  
//        } catch (SQLException ex) {  
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);  
//        }  
//            return 0; 
//    }
    
//    public static ResultSet show_invoice(String email){ 
//            try { 
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
//            Statement st = c.createStatement(); 
//            String sql = "select product_name, orderd_quantity, price from product inner join invoice on " 
//                    + "invoice.product_name = product.name where email = '"+email+"'"; 
//            ResultSet resultSet = st.executeQuery(sql); 
//            return resultSet; 
//        } catch (ClassNotFoundException ex) { 
//            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE); 
//        } catch (SQLException ex) { 
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
//        } 
//    return null; 
//    }     
//        public static void add_invoice(String email, String product_name, int ordered_quantity){  
//            try {  
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");  
//            Statement st = c.createStatement();  
//            String sql = "select * from product where [name] = '"+product_name+"'";  
//            ResultSet s = st.executeQuery(sql);  
//            int x= 0; while(s.next()){  
//                x = s.getInt("quantity");  
//            }  
//            if(ordered_quantity > x)  
//                JOptionPane.showMessageDialog(null, "too much quantity", "Error", JOptionPane.ERROR_MESSAGE);  
//            else{  
//                x = x - ordered_quantity;  
//                sql="update product set quantity = '"+x+"' where [name] = '"+product_name+"'";   
//                int y = st.executeUpdate(sql); 
//                sql="insert into invoice values('"+email+"','"+product_name+"','"+ordered_quantity+"',)"; 
//                int z = st.executeUpdate(sql); 
//                if(y==1 && z==1)   
//                    JOptionPane.showMessageDialog(null,"product ordered","SUCCESS",JOptionPane.INFORMATION_MESSAGE);   
//                else   
//                    JOptionPane.showMessageDialog(null,"order failed","Failed",JOptionPane.INFORMATION_MESSAGE);   
//            }  
//        } catch (ClassNotFoundException ex) {  
//            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE);  
//        } catch (SQLException ex) {  
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);  
//        }  
//    } 
//        public static ResultSet show_products_client(){ 
//            try { 
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
//            Statement st = c.createStatement(); 
//            String sql = "select name, quantity, price from product"; 
//            ResultSet resultSet = st.executeQuery(sql); 
//            return resultSet; 
//        } catch (ClassNotFoundException ex) { 
//            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE); 
//        } catch (SQLException ex) { 
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex); 
//        } 
//    return null; 
//    }
    
//    public static void delete_client(String email){    
//        try {  
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
//            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");   
//            Statement st = c.createStatement();  
//            String sql = "delete from client where email = '"+email+"'" ;  
//            int x = st.executeUpdate(sql); 
//            if(x==1) 
//                JOptionPane.showMessageDialog(null,"account is deleted","SUCCESS",JOptionPane.INFORMATION_MESSAGE); 
//            else 
//                JOptionPane.showMessageDialog(null,"account is not deleted","Failed",JOptionPane.INFORMATION_MESSAGE);  
//        } catch (ClassNotFoundException ex) {  
//            JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE);  
//        } catch (SQLException ex) {  
//            Logger.getLogger(Inventory.class.getName()).log(Level.SEVERE, null, ex);  
//        } 
//    }
}


        
//        int t = is_client("client2@inventory", "2222");
//        System.out.println(t);
        

//        int s = is_admin("admin2", "22");
//        System.out.println(s);
 

//    ResultSet s = show_invoice(3);
//        while (s.next()) {
//                       System.out.println(
//                                               s.getString("product_name") 
//                                       + " " + s.getInt("price")
//                                       + " " + s.getInt("quantity")
//                       );
//        }


//        ResultSet s = show_offers();
//        while (s.next()) {
//                       System.out.println( 
//                                       s.getString("product_name") 
//                                       + " " + s.getString("start_date") 
//                                       + " " + s.getString("end_date")
//                                       + " " + s.getInt("quantity")
//                                       + " " + s.getInt("percentage")
//                       );
//        }


//        ResultSet s = show_products();
//        while (s.next()) {
//                       System.out.println(
//                                               s.getInt("id") 
//                                       + " " + s.getString("name") 
//                                       + " " + s.getString("production_date") 
//                                       + " " + s.getString("expiration_date")
//                                       + " " + s.getInt("price")
//                                       + " " + s.getInt("rate")
//                                       + " " + s.getInt("quantity")
//                                       + " " + s.getString("category_name")
//                       );
//                   }

//        add_supplier("sup4", "pro2");      
//        add_product("pro6", 45, 15, "cat1", "10", "20");
//        add_client("client4@inventory", "4444");
//        add_category("cat4");
//        add_offer("pro2", 5, "5", "15", 50);
//        update_product(3, "pro7", 45, 15, "cat1", "10", "20");