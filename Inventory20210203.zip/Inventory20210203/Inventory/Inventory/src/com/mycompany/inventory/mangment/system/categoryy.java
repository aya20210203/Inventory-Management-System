/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inventory.mangment.system;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 *
 * @author asus
 */
public class categoryy  {
    private static int categoryId;
    private String categoryName;

  

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
        categoryId++;
    }
  public static void add_category(String name){   
      try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
            Statement st = c.createStatement();
            String sql="insert into category(name) values('"+name+"')";
            int x = st.executeUpdate(sql);
            if(x==1)
                JOptionPane.showMessageDialog(null,"data has been recorded","SUCCESS",JOptionPane.INFORMATION_MESSAGE);
            else
                JOptionPane.showMessageDialog(null,"data has NOT been recorded","Failed",JOptionPane.INFORMATION_MESSAGE);
            } catch (ClassNotFoundException ex) { 
                JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE); 
            } catch (SQLException ex) { 
                Logger.getLogger(inventory.system.Inventory.class.getName()).log(Level.SEVERE, null, ex); 
        }
     }
  
  public static int  delete_category(String name){   
        int x=0;   
        try {  
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");   
            Statement st = c.createStatement();  
            String sql = "delete from category where name = '"+name+"'" ;  
            x = st.executeUpdate(sql); 
        } catch (ClassNotFoundException ex) {  
            JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE);  
        } catch (SQLException ex) {  
            Logger.getLogger(inventory.system.Inventory.class.getName()).log(Level.SEVERE, null, ex);  
        } 
        return x; 
    }
   public static ResultSet show_category(){
            try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123");
            Statement st = c.createStatement();
            String sql = "select category.id, category.name as name, product.name as p_name from category left join product on category.name = product.category_name order by id";
            ResultSet resultSet = st.executeQuery(sql);
            return resultSet;
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "connector not found!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            Logger.getLogger(inventory.system.Inventory.class.getName()).log(Level.SEVERE, null, ex);
        }
    return null;
    }
    public static void update_category(String old_name, String new_name){    
            try { 
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
            Connection c = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=inventory;encrypt=true;trustServerCertificate=true;","sa" ,"123"); 
            Statement st = c.createStatement(); 
            String sql="update category set name = '"+new_name+"' where name = '"+old_name+"'"; 
            int x = st.executeUpdate(sql); 
            if(x==1) 
                JOptionPane.showMessageDialog(null,"data has been recorded","SUCCESS",JOptionPane.INFORMATION_MESSAGE); 
            else 
                JOptionPane.showMessageDialog(null,"data has NOT been recorded","Failed",JOptionPane.INFORMATION_MESSAGE); 
            } catch (ClassNotFoundException ex) {  
                JOptionPane.showMessageDialog(null, "connector not found", "Error", JOptionPane.ERROR_MESSAGE);  
            } catch (SQLException ex) {  
                Logger.getLogger(inventory.system.Inventory.class.getName()).log(Level.SEVERE, null, ex);  
        } 
     } 

    
}
